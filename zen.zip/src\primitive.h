#ifndef PRIMITIVE_H
#define PRIMITIVE_H

#include <stdbool.h>

typedef unsigned int uint;

#endif // PRIMITIVE_H