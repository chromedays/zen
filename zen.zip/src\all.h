#ifndef ALL_H
#define ALL_H
#include "app.h"
#include "debug.h"
#include "example.h"
#include "filesystem.h"
#include "primitive.h"
#include "renderer.h"
#include "resource.h"
#include "scene.h"
#include "util.h"
#endif // ALL_H